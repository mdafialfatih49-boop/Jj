package com.fusionmachine;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class FusionMod implements ModInitializer {
    public static final String ID = "fusionmachine";

    public static final FusedBlock FUSED_BLOCK = new FusedBlock(
            AbstractBlock.Settings.copy(Blocks.STONE).strength(2.0f, 6.0f)
                    .luminance(s -> s.get(FusedBlock.LIGHT)));
    public static BlockEntityType<FusedBlockEntity> FUSED_BE;

    @Override
    public void onInitialize() {
        Identifier id = new Identifier(ID, "fused_block");
        Registry.register(Registries.BLOCK, id, FUSED_BLOCK);
        Registry.register(Registries.ITEM, id, new FusedBlockItem(FUSED_BLOCK, new Item.Settings()));
        FUSED_BE = Registry.register(Registries.BLOCK_ENTITY_TYPE, id,
                FabricBlockEntityTypeBuilder.create(FusedBlockEntity::new, FUSED_BLOCK).build());
    }
}
