package com.fusionmachine;

import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class FusedBlockItem extends BlockItem {
    public FusedBlockItem(Block block, Settings settings) {
        super(block, settings);
    }

    @Override
    public Text getName(ItemStack stack) {
        NbtCompound tag = stack.getSubNbt("BlockEntityTag");
        if (tag != null && tag.contains("BlockA") && tag.contains("BlockB")) {
            Block a = Registries.BLOCK.get(new Identifier(tag.getString("BlockA")));
            Block b = Registries.BLOCK.get(new Identifier(tag.getString("BlockB")));
            if (a == b) return Text.translatable("fusionmachine.fused.super", a.getName());
            return Text.translatable("fusionmachine.fused.named", a.getName(), b.getName());
        }
        return super.getName(stack);
    }
}
