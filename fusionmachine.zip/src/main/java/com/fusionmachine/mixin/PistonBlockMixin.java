package com.fusionmachine.mixin;

import com.fusionmachine.Fusion;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PistonBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PistonBlock.class)
public abstract class PistonBlockMixin {
    @Inject(method = "tryMove", at = @At("HEAD"), cancellable = true)
    private void fusionmachine$fuse(World world, BlockPos pos, BlockState state, CallbackInfo ci) {
        if (world.isClient || !state.isOf(Blocks.STICKY_PISTON)) return;
        if (Fusion.tryFuse(world, pos, state)) ci.cancel();
    }
}
