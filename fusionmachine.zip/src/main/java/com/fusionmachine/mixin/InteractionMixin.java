package com.fusionmachine.mixin;

import com.fusionmachine.FusedBlockEntity;
import net.minecraft.server.network.ServerPlayerInteractionManager;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ServerPlayerInteractionManager.class)
public abstract class InteractionMixin {
    @Shadow protected ServerWorld world;

    /** Block gabungan "unbreakable" tidak bisa dihancurkan, termasuk di creative. */
    @Inject(method = "tryBreakBlock", at = @At("HEAD"), cancellable = true)
    private void fusionmachine$noBreak(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
        if (world.getBlockEntity(pos) instanceof FusedBlockEntity f && f.isUnbreakable()) {
            cir.setReturnValue(false);
        }
    }
}
