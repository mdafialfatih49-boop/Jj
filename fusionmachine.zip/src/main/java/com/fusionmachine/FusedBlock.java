package com.fusionmachine;

import net.minecraft.block.*;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class FusedBlock extends BlockWithEntity {
    public static final IntProperty LIGHT = IntProperty.of("light", 0, 15);

    public FusedBlock(Settings settings) {
        super(settings);
        setDefaultState(getStateManager().getDefaultState().with(LIGHT, 0));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(LIGHT);
    }

    @Override
    public BlockRenderType getRenderType(BlockState state) {
        return BlockRenderType.ENTITYBLOCK_ANIMATED;
    }

    @Nullable
    @Override
    public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new FusedBlockEntity(pos, state);
    }

    private static FusedBlockEntity be(BlockView w, BlockPos p) {
        return w.getBlockEntity(p) instanceof FusedBlockEntity f ? f : null;
    }

    /** Kecepatan hancur memakai kekerasan hasil gabungan (disimpan per block). */
    @Override
    public float calcBlockBreakingDelta(BlockState state, PlayerEntity player, BlockView world, BlockPos pos) {
        FusedBlockEntity f = be(world, pos);
        float h = f == null ? 2.0f : f.getHardness();
        if (h < 0) return 0.0f;
        int i = player.canHarvest(state) ? 30 : 100;
        return player.getBlockBreakingSpeed(state) / h / i;
    }

    /** Magma di salah satu bahan: melukai yang menginjak. */
    @Override
    public void onSteppedOn(World world, BlockPos pos, BlockState state, Entity entity) {
        FusedBlockEntity f = be(world, pos);
        if (f != null && f.has(Blocks.MAGMA_BLOCK) && !entity.bypassesSteppingEffects()
                && entity instanceof LivingEntity) {
            entity.damage(world.getDamageSources().hotFloor(), 1.0f);
        }
        super.onSteppedOn(world, pos, state, entity);
    }

    /** Slime di salah satu bahan: memantul. */
    @Override
    public void onLandedUpon(World world, BlockState state, BlockPos pos, Entity entity, float fallDistance) {
        FusedBlockEntity f = be(world, pos);
        if (f != null && f.has(Blocks.SLIME_BLOCK) && !entity.bypassesLandingEffects()) {
            entity.handleFallDamage(fallDistance, 0.0f, world.getDamageSources().fall());
        } else {
            super.onLandedUpon(world, state, pos, entity, fallDistance);
        }
    }

    @Override
    public void onEntityLand(BlockView world, Entity entity) {
        Entity e = entity;
        BlockPos below = e.getBlockPos().down();
        FusedBlockEntity f = be(world, below);
        if (f != null && f.has(Blocks.SLIME_BLOCK) && !e.bypassesLandingEffects()) {
            Vec3d v = e.getVelocity();
            if (v.y < 0.0) {
                double d = e instanceof LivingEntity ? 1.0 : 0.8;
                e.setVelocity(v.x, -v.y * d, v.z);
            }
        } else {
            super.onEntityLand(world, entity);
        }
    }

    /** Redstone block di salah satu bahan: memancarkan sinyal 15. */
    @Override
    public boolean emitsRedstonePower(BlockState state) {
        return true;
    }

    @Override
    public int getWeakRedstonePower(BlockState state, BlockView world, BlockPos pos, Direction direction) {
        FusedBlockEntity f = be(world, pos);
        return f != null && f.has(Blocks.REDSTONE_BLOCK) ? 15 : 0;
    }

    /** TNT di salah satu bahan: meledak kalau kena sinyal redstone. */
    @Override
    public void neighborUpdate(BlockState state, World world, BlockPos pos, Block sourceBlock,
                               BlockPos sourcePos, boolean notify) {
        if (world.isClient) return;
        FusedBlockEntity f = be(world, pos);
        if (f != null && f.has(Blocks.TNT) && world.isReceivingRedstonePower(pos)) {
            world.removeBlock(pos, false);
            world.createExplosion(null, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                    4.0f, World.ExplosionSourceType.TNT);
        }
    }
}
