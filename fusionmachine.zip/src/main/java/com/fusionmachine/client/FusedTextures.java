package com.fusionmachine.client;

import com.fusionmachine.mixin.SpriteContentsAccessor;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.texture.Sprite;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;

/** Membuat texture 16x16 baru dari campuran texture dua block. */
public class FusedTextures {
    private static final Map<String, Identifier> CACHE = new HashMap<>();
    private static int counter = 0;

    public static Identifier get(Block a, Block b) {
        String key = Registries.BLOCK.getId(a) + "|" + Registries.BLOCK.getId(b);
        Identifier cached = CACHE.get(key);
        if (cached != null) return cached;
        NativeImage img = build(a, b);
        Identifier id = new Identifier("fusionmachine", "fused/t" + (counter++));
        MinecraftClient.getInstance().getTextureManager().registerTexture(id, new NativeImageBackedTexture(img));
        CACHE.put(key, id);
        return id;
    }

    private static NativeImage build(Block a, Block b) {
        NativeImage out = new NativeImage(16, 16, false);
        try {
            Sprite sa = sprite(a), sb = sprite(b);
            NativeImage ia = ((SpriteContentsAccessor) sa.getContents()).fusionmachine$getImage();
            NativeImage ib = ((SpriteContentsAccessor) sb.getContents()).fusionmachine$getImage();
            int wa = sa.getContents().getWidth(), wb = sb.getContents().getWidth();
            boolean same = a == b;
            for (int y = 0; y < 16; y++) {
                for (int x = 0; x < 16; x++) {
                    int ca = ia.getColor(x * wa / 16, y * wa / 16);
                    int cb = ib.getColor(x * wb / 16, y * wb / 16);
                    int c;
                    if (same) {
                        c = ca;
                        if ((x + y) % 6 == 0) c = mix(c, 0xFFFF3CAA, 0.55f); // urat ungu "Super"
                    } else {
                        c = (((x / 4) + (y / 4)) & 1) == 0 ? ca : cb;       // mosaik 4x4
                        if (alpha(c) == 0) c = (c == ca) ? cb : ca;
                    }
                    out.setColor(x, y, c | 0xFF000000);
                }
            }
        } catch (Throwable t) {
            for (int y = 0; y < 16; y++)
                for (int x = 0; x < 16; x++)
                    out.setColor(x, y, ((x + y) & 1) == 0 ? 0xFFAA3CFF : 0xFF444444);
        }
        return out;
    }

    private static Sprite sprite(Block b) {
        return MinecraftClient.getInstance().getBlockRenderManager().getModels()
                .getModelParticleSprite(b.getDefaultState());
    }

    private static int alpha(int c) { return (c >>> 24) & 255; }

    // warna NativeImage berformat ABGR
    private static int mix(int c1, int c2, float t) {
        int r = (int) ((c1 & 255) * (1 - t) + (c2 & 255) * t);
        int g = (int) (((c1 >> 8) & 255) * (1 - t) + ((c2 >> 8) & 255) * t);
        int bl = (int) (((c1 >> 16) & 255) * (1 - t) + ((c2 >> 16) & 255) * t);
        return 0xFF000000 | (bl << 16) | (g << 8) | r;
    }
}
