package com.fusionmachine.client;

import com.fusionmachine.FusionMod;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactories;

public class FusionClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockEntityRendererFactories.register(FusionMod.FUSED_BE, FusedRenderer::new);
    }
}
