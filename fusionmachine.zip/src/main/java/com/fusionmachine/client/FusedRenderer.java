package com.fusionmachine.client;

import com.fusionmachine.FusedBlock;
import com.fusionmachine.FusedBlockEntity;
import net.minecraft.client.render.*;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

public class FusedRenderer implements BlockEntityRenderer<FusedBlockEntity> {
    public FusedRenderer(BlockEntityRendererFactory.Context ctx) {}

    // 4 titik tiap sisi: BL, BR, TR, TL
    private static final float[][][] FACES = {
        /*DOWN */ {{0,0,1},{1,0,1},{1,0,0},{0,0,0}},
        /*UP   */ {{0,1,0},{1,1,0},{1,1,1},{0,1,1}},
        /*NORTH*/ {{1,0,0},{0,0,0},{0,1,0},{1,1,0}},
        /*SOUTH*/ {{0,0,1},{1,0,1},{1,1,1},{0,1,1}},
        /*WEST */ {{0,0,0},{0,0,1},{0,1,1},{0,1,0}},
        /*EAST */ {{1,0,1},{1,0,0},{1,1,0},{1,1,1}}
    };
    private static final float[][] UV = {{0,1},{1,1},{1,0},{0,0}};

    @Override
    public void render(FusedBlockEntity be, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vcp, int light, int overlay) {
        World w = be.getWorld();
        if (w == null) return;
        Identifier tex = FusedTextures.get(be.blockA(), be.blockB());
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(tex));
        MatrixStack.Entry e = matrices.peek();
        Matrix4f pm = e.getPositionMatrix();
        Matrix3f nm = e.getNormalMatrix();
        boolean glow = be.getCachedState().get(FusedBlock.LIGHT) > 0;

        for (Direction d : Direction.values()) {
            // cahaya diambil dari block di sebelah sisi ini (block sendiri opaque = gelap)
            int l = glow ? LightmapTextureManager.MAX_LIGHT_COORDINATE
                         : WorldRenderer.getLightmapCoordinates(w, be.getPos().offset(d));
            float[][] f = FACES[d.getId()];
            for (int i = 0; i < 4; i++) {
                vc.vertex(pm, f[i][0], f[i][1], f[i][2])
                  .color(255, 255, 255, 255)
                  .texture(UV[i][0], UV[i][1])
                  .overlay(overlay)
                  .light(l)
                  .normal(nm, d.getOffsetX(), d.getOffsetY(), d.getOffsetZ())
                  .next();
            }
        }
    }
}
