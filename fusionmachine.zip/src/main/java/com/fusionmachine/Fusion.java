package com.fusionmachine;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PistonBlock;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

public class Fusion {

    public static boolean fusible(World w, BlockPos p, BlockState s) {
        return !s.isAir() && !s.hasBlockEntity() && !s.isOf(FusionMod.FUSED_BLOCK)
                && s.getFluidState().isEmpty() && s.isFullCube(w, p);
    }

    /** Susunan: [sticky piston] [A] [B] [sticky piston], saling berhadapan. */
    public static boolean tryFuse(World world, BlockPos pistonPos, BlockState piston) {
        if (world.isClient || !(world instanceof ServerWorld sw)) return false;
        if (piston.get(PistonBlock.EXTENDED)) return false;
        if (!world.isReceivingRedstonePower(pistonPos)) return false;

        Direction dir = piston.get(PistonBlock.FACING);
        BlockPos pa = pistonPos.offset(dir);
        BlockPos pb = pa.offset(dir);
        BlockPos p2 = pb.offset(dir);

        BlockState other = world.getBlockState(p2);
        if (!other.isOf(Blocks.STICKY_PISTON)
                || other.get(PistonBlock.FACING) != dir.getOpposite()
                || other.get(PistonBlock.EXTENDED)) return false;

        BlockState sa = world.getBlockState(pa);
        BlockState sb = world.getBlockState(pb);
        if (!fusible(world, pa, sa) || !fusible(world, pb, sb)) return false;

        Block a = sa.getBlock();
        Block b = sb.getBlock();

        float hA = sa.getHardness(world, pa);
        float hB = sb.getHardness(world, pb);
        float hardness;
        if (hA < 0 || hB < 0) hardness = -1.0f;            // ada bedrock -> unbreakable
        else if (a == b) hardness = Math.max(hA, hB) * 2.0f; // "Super X"
        else hardness = (hA + hB) * 0.75f;                   // campuran

        int light = Math.max(sa.getLuminance(), sb.getLuminance());

        // flag 2 = tanpa neighbor update, supaya piston tidak langsung mendorong hasilnya
        world.setBlockState(pb, Blocks.AIR.getDefaultState(), 2);
        world.setBlockState(pa, FusionMod.FUSED_BLOCK.getDefaultState().with(FusedBlock.LIGHT, light), 2);
        if (world.getBlockEntity(pa) instanceof FusedBlockEntity be) {
            be.setFusion(a, b, hardness);
        }

        sw.spawnParticles(ParticleTypes.END_ROD, pb.getX() + 0.5, pb.getY() + 0.5, pb.getZ() + 0.5,
                25, 0.6, 0.6, 0.6, 0.05);
        world.playSound(null, pa, SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.BLOCKS, 1.0f, 0.8f);
        return true;
    }
}
