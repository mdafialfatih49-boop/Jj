package com.fusionmachine;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import org.jetbrains.annotations.Nullable;

public class FusedBlockEntity extends BlockEntity {
    private String idA = "minecraft:stone";
    private String idB = "minecraft:stone";
    private float hardness = 2.0f;

    public FusedBlockEntity(BlockPos pos, BlockState state) {
        super(FusionMod.FUSED_BE, pos, state);
    }

    public void setFusion(Block a, Block b, float hardness) {
        this.idA = Registries.BLOCK.getId(a).toString();
        this.idB = Registries.BLOCK.getId(b).toString();
        this.hardness = hardness;
        markDirty();
        if (world != null && !world.isClient) {
            world.updateListeners(pos, getCachedState(), getCachedState(), 3);
        }
    }

    public Block blockA() { return Registries.BLOCK.get(new Identifier(idA)); }
    public Block blockB() { return Registries.BLOCK.get(new Identifier(idB)); }
    public boolean has(Block b) { return blockA() == b || blockB() == b; }
    public float getHardness() { return hardness; }
    public boolean isUnbreakable() { return hardness < 0; }

    @Override
    protected void writeNbt(NbtCompound nbt) {
        super.writeNbt(nbt);
        nbt.putString("BlockA", idA);
        nbt.putString("BlockB", idB);
        nbt.putFloat("Hardness", hardness);
    }

    @Override
    public void readNbt(NbtCompound nbt) {
        super.readNbt(nbt);
        if (nbt.contains("BlockA")) idA = nbt.getString("BlockA");
        if (nbt.contains("BlockB")) idB = nbt.getString("BlockB");
        if (nbt.contains("Hardness")) hardness = nbt.getFloat("Hardness");
    }

    @Nullable
    @Override
    public Packet<ClientPlayPacketListener> toUpdatePacket() {
        return BlockEntityUpdateS2CPacket.create(this);
    }

    @Override
    public NbtCompound toInitialChunkDataNbt() {
        return createNbt();
    }
}
