# Fusion Machine (Fabric 1.20.1)

Susunan: [sticky piston] [block A] [block B] [sticky piston], dua piston saling berhadapan.
Nyalakan dengan lever -> A dan B menyatu jadi satu Fused Block.

Fungsi otomatis:
- Texture: campuran mosaik 4x4 dari texture kedua block (dibuat saat game jalan)
- Kekerasan: (A + B) x 0.75; block sama + block sama = "Super X" (kekerasan x2, urat ungu)
- Cahaya: ikut yang paling terang
- Ada bedrock: tidak bisa dihancurkan (termasuk creative)
- Magma: melukai yang menginjak | Slime: memantul
- Redstone block: memancarkan sinyal 15 | TNT: meledak kena redstone

Build: push ke GitHub -> tab Actions -> unduh artifact fusionmachine-jar.
